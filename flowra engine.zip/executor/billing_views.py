import os
import hmac
import hashlib
import json
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Coupon, WorkspaceSubscription, AICreditLedger, AICreditTransaction

class FetchCouponsView(APIView):
    def get(self, request):
        coupons = Coupon.objects.filter(is_active=True).values('code', 'discount_percent', 'discount_amount')
        return Response({"coupons": list(coupons)}, status=status.HTTP_200_OK)


class RazorpayCheckoutView(APIView):
    def post(self, request):
        # In a real scenario, this would use Razorpay SDK: `razorpay_client.order.create(...)`
        # Mocking for now since we don't have the library installed.
        plan_id = request.data.get("plan_id")
        workspace_id = request.data.get("workspace_id")
        
        # Mock order generation
        order_id = f"order_{os.urandom(4).hex()}"
        return Response({"order_id": order_id}, status=status.HTTP_200_OK)


class RazorpayWebhookView(APIView):
    def post(self, request):
        # Basic signature verification mock
        webhook_secret = os.getenv("RAZORPAY_WEBHOOK_SECRET", "mock_secret")
        # In a real app, verify signature using hmac
        
        payload = request.data
        event = payload.get("event")
        
        if event == "subscription.activated":
            sub_id = payload.get("payload", {}).get("subscription", {}).get("entity", {}).get("id")
            # Update local subscription status
            try:
                sub = WorkspaceSubscription.objects.get(razorpay_subscription_id=sub_id)
                sub.status = "active"
                sub.save()
            except WorkspaceSubscription.DoesNotExist:
                pass
                
        # Grant AI credits for Premium or AI add-ons
        # (This is just scaffolding for the webhook)
        return Response({"status": "ok"}, status=status.HTTP_200_OK)
