from django.urls import path
from .views import ExecuteWorkflowView, PollSheetsView
from .billing_views import FetchCouponsView, RazorpayCheckoutView, RazorpayWebhookView

urlpatterns = [
    path('workflow/', ExecuteWorkflowView.as_view(), name='execute_workflow'),
    path('poll-sheets/', PollSheetsView.as_view(), name='poll_sheets'),
    
    # Billing
    path('billing/coupons/', FetchCouponsView.as_view(), name='fetch_coupons'),
    path('billing/checkout/', RazorpayCheckoutView.as_view(), name='razorpay_checkout'),
    path('billing/webhook/', RazorpayWebhookView.as_view(), name='razorpay_webhook'),
]
